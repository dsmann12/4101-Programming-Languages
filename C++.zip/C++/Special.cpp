// Special.cpp -- the implementation of the special form classes

#include "Special.h"

void
Quote::print(Node * t, int n, bool p) {
  // TODO: implement this function.
}

void
Lambda::print(Node * t, int n, bool p) {
  // TODO: implement this function.
}

void
Begin::print(Node * t, int n, bool p) {
  // TODO: implement this function.
}

void
If::print(Node * t, int n, bool p) {
  // TODO: implement this function.
}

void
Let::print(Node * t, int n, bool p) {
  // TODO: implement this function.
}

void
Cond::print(Node * t, int n, bool p) {
  // TODO: implement this function.
}

void
Define::print(Node * t, int n, bool p) {
  // TODO: implement this function.
}

void
Set::print(Node * t, int n, bool p) {
  // TODO: implement this function.
}

void
Regular::print(Node * t, int n, bool p) {
  // TODO: implement this function.
}
